<?php get_header(); ?> 

<?php get_template_part('template-parts/header-section');?>

<main class="page">



</main>

<?php get_footer(); ?>  