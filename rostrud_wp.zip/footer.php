<footer id="footer" class="footer">
	<div class="footer__container _container">

		<div class="footer__row d-flex">

			<a href="index.html" class="logo-icon footer__logo">
				<!-- <? bloginfo("url"); ?> -->
			</a>

			<ul class="footer__menu">
				<li class="footer__menu-item"><a href="#" class="footer__menu-item-link">Главная</a></li>
				<li class="footer__menu-item"><a href="#" class="footer__menu-item-link">Наши клиенты и партнеры</a></li>
				<li class="footer__menu-item"><a href="#" class="footer__menu-item-link">О нас</a></li>
				<li class="footer__menu-item"><a href="services.html" class="footer__menu-item-link">Услуги</a></li>
				<li class="footer__menu-item"><a href="#" class="footer__menu-item-link">Акции</a></li>
				<li class="footer__menu-item"><a href="#" class="footer__menu-item-link">Отзывы</a></li>
				<li class="footer__menu-item"><a href="security.html" class="footer__menu-item-link">Аккредитации и лицензии</a></li>
				<li class="footer__menu-item"><a href="#" class="footer__menu-item-link">Контакты</a></li>
			</ul>

			<div class="footer__address">
				<p class="footer__address-text">г. Курск, ул.1-я Пушкарная, д. 28</p>
				<a href="mailto:ros-trud@mail.ru" class="footer__address-email">ros-trud@mail.ru</a>
			</div>

			<div class="footer__contacts">
				<a href="tel:+74712550286" class="footer__contacts-phone">+7 (4712) 55-02-86</a>
				<a href="tel:+79513106993" class="footer__contacts-phone">+7 (951) 310-69-93</a>
				<a href="#callback" class="footer__popup-link btn _popup-link">ЗАКАЗАТЬ ЗВОНОК</a>
			</div>

		</div>

	</div>
</footer>
</div>

<?php wp_footer(); ?>
</body>
</html>